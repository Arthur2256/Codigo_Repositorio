import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { Header } from '../components/header';
import { Button } from '../components/button';

const NewAccountScreen = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    watch
  } = useForm({
    defaultValues: {
      nome: '',
      email: '',
      telefone: '',
      animal: '',
      senha: '',
      confirmarsenha: '',
    }
  });

  const senha = watch('senha');

  const onSubmit = (data) => {
    alert('Dados enviados!\n\n' + JSON.stringify(data, null, 2));
  };

  return (
    <View style={styles.container}>
      <Header title="Informações de Cadastro" />
      <View style={styles.formBox}>
        <Text style={styles.label}>Nome</Text>
        <Controller
          control={control}
          name="nome"
          rules={{ required: 'Nome obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.nome && <Text style={styles.error}>{errors.nome.message}</Text>}

        <Text style={styles.label}>Email</Text>
        <Controller
          control={control}
          name="email"
          rules={{ required: 'Email obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

        <Text style={styles.label}>Telefone ou WhatsApp</Text>
        <Controller
          control={control}
          name="telefone"
          rules={{ required: 'Telefone obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.telefone && <Text style={styles.error}>{errors.telefone.message}</Text>}

        <Text style={styles.label}>Qual é o nome do seu primeiro animal de estimação?</Text>
        <Controller
          control={control}
          name="animal"
          rules={{ required: 'Campo obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.animal && <Text style={styles.error}>{errors.animal.message}</Text>}

        <Text style={styles.label}>Senha</Text>
        <Controller
          control={control}
          name="senha"
          rules={{
            required: 'Senha obrigatória',
            minLength: {
              value: 6,
              message: 'A senha deve ter no mínimo 6 caracteres',
            }
          }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite sua senha"
              onChangeText={onChange}
              value={value}
              maxLength={6}
              secureTextEntry
            />
          )}
        />
        {errors.senha && <Text style={styles.error}>{errors.senha.message}</Text>}

        <Text style={styles.label}>Confirmar Senha</Text>
        <Controller
          control={control}
          name="confirmarsenha"
          rules={{
            required: 'Confirmação de senha obrigatória',
            validate: value =>
              value === senha || 'As senhas não coincidem'
          }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Confirme senha"
              onChangeText={onChange}
              value={value}
              maxLength={6}
              secureTextEntry
            />
          )}
        />
        {errors.confirmarsenha && (
          <Text style={styles.error}>{errors.confirmarsenha.message}</Text>
        )}
      </View>

      <View style={styles.buttoncontainer}>
        <Button title="Finalizar" onPress={handleSubmit(onSubmit)} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#1e3f70',
  },
  formBox: {
    backgroundColor: '#f4f4f4',
    padding: 15,
    borderRadius: 8,
  },
  buttoncontainer: {
    marginTop: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    marginLeft: 1,
    marginTop: 10,
    color: '#222',
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  error: {
    color: 'red',
    fontSize: 12,
    marginBottom: 8,
  },
});

export default NewAccountScreen;