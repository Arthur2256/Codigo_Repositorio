import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { Header } from '../components/header';
import { Button } from '../components/button';

const ForgotPasswordScreen = ({ navigation }) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm({
    defaultValues: {
      email: '',
      animal: '',
      password: '',
      confirmPassword: '',
    },
  });

  const password = watch('password');

  const onSubmit = (data) => {
    alert('Dados enviados!\n\n' + JSON.stringify(data, null, 2));
  };

  return (
    <View style={styles.container}>
      <Header title="Redefinição de Senha" />
      <View style={styles.formBox}>
        <Text style={styles.label}>Email</Text>
        <Controller
          control={control}
          name="email"
          rules={{
            required: 'Email obrigatório',
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
              message: 'Email inválido',
            },
          }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          )}
        />
        {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

        <Text style={styles.label}>Qual é o nome do seu primeiro animal de estimação?</Text>
        <Controller
          control={control}
          name="animal"
          rules={{ required: 'Campo obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.animal && <Text style={styles.error}>{errors.animal.message}</Text>}
      </View>
      <View style={styles.buttoncontainer}>
        <Button title="Redefinir Senha" onPress={handleSubmit(() => navigation.navigate('NewPassword'))} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#1e3f70',
  },
  formBox: {
    backgroundColor: '#f4f4f4',
    padding: 15,
    borderRadius: 8,
  },
  buttoncontainer: {
    marginTop: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    marginLeft: 1,
    marginTop: 10,
    color: '#222',
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  error: {
    color: 'red',
    fontSize: 12,
    marginBottom: 8,
  },
});

export default ForgotPasswordScreen;
