import React, { useLayoutEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';

function AdminRequestsScreen() {
  const navigation = useNavigation(); // pega o objeto de navegação corretamente

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.atendimento}>
          <Text style={styles.label}>
            Número do pedido: <Text style={styles.value}>202412345678</Text>
          </Text>

          <View style={styles.rowBetween}>
            <Text style={styles.username}>João Silva</Text>
            <Text style={styles.date}>21/06/2025</Text>
          </View>

          <View style={styles.rowBetween}>
            <Text style={styles.phone}>(11) 91234-5678</Text>
            <TouchableOpacity onPress={() => navigation.navigate('RequestDetails')}>
              <Text style={styles.detailsLink}>Ver detalhes</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.trashContainer}>
            <TouchableOpacity onPress={() => console.log('Excluir pedido')}>
              <Ionicons name="trash-outline" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.atendimento}>
          <Text style={styles.label}>
            Número do pedido: <Text style={styles.value}>202412345677</Text>
          </Text>

          <View style={styles.rowBetween}>
            <Text style={styles.username}>João Silva</Text>
            <Text style={styles.date}>20/06/2025</Text>
          </View>

          <View style={styles.rowBetween}>
            <Text style={styles.phone}>(11) 91234-5678</Text>
            <TouchableOpacity onPress={() => navigation.navigate('RequestDetails')}>
              <Text style={styles.detailsLink}>Ver detalhes</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.trashContainer}>
            <TouchableOpacity onPress={() => console.log('Excluir pedido')}>
              <Ionicons name="trash-outline" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100,
  },
  atendimento: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },
  label: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  value: {
    fontWeight: 'normal',
  },
  username: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    paddingRight: 140,
  },
  date: {
    fontSize: 18,
    color: '#666',
  },
  phone: {
    fontSize: 16,
    color: '#333',
    paddingRight: 125,
  },
  detailsLink: {
    fontSize: 16,
    color: '#007AFF',
    textDecorationLine: 'underline',
  },
  trashContainer: {
    width: '100%',
    alignItems: 'flex-end',
    marginTop: 10,
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
});

export default AdminRequestsScreen;

