import React from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { Header } from '../components/header';
import { Button } from '../components/button';

const NewPasswordScreen = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    watch
  } = useForm({
    defaultValues: {
      password: '',
      confirmPassword: '',
    }
  });

  const password = watch('password');

  const onSubmit = (data) => {
    alert('Dados enviados!\n\n' + JSON.stringify(data, null, 2));
  };

  return (
    <View style={styles.container}>
      <Header title="Redefinição de Senha" />
      <View style={styles.formBox}>
        {/* --- Campo: Nova Senha --- */}
        <Text style={styles.label}>Nova Senha</Text>
        <Controller
          control={control}
          name="password"
          rules={{
            required: 'Senha obrigatória',
            minLength: {
              value: 6,
              message: 'A senha deve ter no mínimo 6 caracteres'
            }
          }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite sua nova senha"
              onChangeText={onChange}
              value={value}
              maxLength={6}
              secureTextEntry
            />
          )}
        />
        {errors.password && <Text style={styles.error}>{errors.password.message}</Text>}

        {/* --- Campo: Confirmar Senha --- */}
        <Text style={styles.label}>Confirmar Senha</Text>
        <Controller
          control={control}
          name="confirmPassword"
          rules={{
            required: 'Confirmação de senha obrigatória',
            validate: value =>
              value === password || 'As senhas não coincidem'
          }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Confirme sua nova senha"
              onChangeText={onChange}
              value={value}
              maxLength={6}
              secureTextEntry
            />
          )}
        />
        {errors.confirmPassword && (
          <Text style={styles.error}>{errors.confirmPassword.message}</Text>
        )}
      </View>

      <View style={styles.buttoncontainer}>
        <Button title="Finalizar" onPress={handleSubmit(onSubmit)} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#1e3f70',
  },
  formBox: {
    backgroundColor: '#f4f4f4',
    padding: 15,
    borderRadius: 8,
  },
  buttoncontainer: {
    marginTop: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    marginLeft: 1,
    marginTop: 10,
    color: '#222',
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  error: {
    color: 'red',
    fontSize: 12,
    marginBottom: 8,
  },
});

export default NewPasswordScreen;
