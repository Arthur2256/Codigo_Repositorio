import React, { useLayoutEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import WorkCalendar from '../components/WorkCalendar';
import { getGreeting } from '../utils/greetings';

const DashboardScreen = ({ navigation }) => {
  useLayoutEffect(() => {
    navigation.setOptions({ title: `${getGreeting()}!` });
  }, [navigation]);

  const marked = {
    '2025-06-25': {
      selected: true,
      selectedColor: '#ff4d4d',
      marked: true,
      dotColor: '#ff0000',
      activeOpacity: 0.8,
    },
  };

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.calendar}>
          <Text style={styles.calendartext}>Calendário de Serviços</Text>
          <WorkCalendar markedDates={marked} />
        </View>

        <View style={styles.atendimento}>
          <Text style={styles.label}>
            Número do pedido: <Text style={styles.value}>202412345679</Text>
          </Text>

          <View style={styles.rowBetween}>
            <Text style={styles.username}>João Silva</Text>
            <Text style={styles.date}>25/06/2025</Text>
          </View>

          <View style={styles.rowBetween}>
            <Text style={styles.phone}>(11) 91234-5677</Text>
            <TouchableOpacity onPress={() => navigation.navigate('RequestDetails')}>
              <Text style={styles.detailsLink}>Ver detalhes</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.trashContainer}>
            <TouchableOpacity onPress={() => console.log('Excluir pedido')}>
              <Ionicons name="trash-outline" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100,
  },
  calendar: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
  },
  calendartext: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#0D2C54',
  },
  atendimento: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  label: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  value: {
    fontWeight: 'normal',
  },
  username: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    paddingRight: 140,
  },
  date: {
    fontSize: 18,
    color: '#666',
  },
  phone: {
    fontSize: 16,
    color: '#333',
    paddingRight: 125,
  },
  detailsLink: {
    fontSize: 16,
    color: '#0D2C54',
    textDecorationLine: 'underline',
  },
  trashContainer: {
    width: '100%',
    alignItems: 'flex-end',
    marginTop: 10,
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
});

export default DashboardScreen;


