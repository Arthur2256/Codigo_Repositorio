import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList } from '@react-navigation/drawer';

import DashboardScreen from '../screens/DashboardScreen';
import AdminRequestsScreen from '../screens/AdminRequestsScreen';

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
  const email = "josesilva@gmail.com";
  const name = "José Silva";

  return (
    <DrawerContentScrollView {...props}>
      <View style={styles.header}>
        <Ionicons name="person-circle" size={60} color="#b0b0b0" />
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.email}>{email}</Text>
      </View>
      <DrawerItemList {...props} />
    </DrawerContentScrollView>
  );
}

function AdminDrawer() {
  return (
      <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      initialRouteName="Dashboard"
      screenOptions={{
        drawerActiveTintColor: '#ffc222',
        drawerInactiveTintColor: '#b0b0b0',
        drawerStyle: { backgroundColor: '#0D2C54' },
        headerStyle: { backgroundColor: '#0D2C54' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
       <Drawer.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{
          drawerLabel: 'Home',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="home" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Pedidos Concluídos"
        component={AdminRequestsScreen}
        options={{
          drawerIcon: ({ color, size }) => (
            <Ionicons name="clipboard" size={size} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#fff',
    alignItems: 'center',
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
    marginTop: 5,
  },
  email: {
    fontSize: 14,
    color: '#ffc222',
    marginTop: 2,
  },
});

export default AdminDrawer;

