import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Button } from '../components/button';
import Ionicons from 'react-native-vector-icons/Ionicons';

function UsersAccountScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Ionicons name="person-circle-outline" size={100} color="#444" style={styles.icon} />
      <Text style={styles.email}>josesilva@gmail.com</Text>
      <Button title='Sobre a empresa' onPress={() => navigation.navigate('About')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  icon: {
    marginBottom: 10,
  },
  email: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
  },
});

export default UsersAccountScreen;

