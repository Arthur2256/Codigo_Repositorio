import React from 'react';
import { View, ScrollView, StyleSheet, Text } from 'react-native';

function RequestDetailsScreen() {
  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Dados do Cliente</Text>
          <Text style={styles.label}>Nome:</Text>
          <Text style={styles.value}>José Silva</Text>

          <Text style={styles.label}>Email:</Text>
          <Text style={styles.value}>josesilva@gmail.com</Text>

          <Text style={styles.label}>Telefone:</Text>
          <Text style={styles.value}>(11) 91234-5678</Text>

          <Text style={styles.label}>Endereço de retirada:</Text>
          <Text style={styles.value}>Rua Primavera, 01</Text>

          <Text style={styles.label}>Endereço de entrega:</Text>
          <Text style={styles.value}>Rua Verão, 02</Text>

          <Text style={styles.label}>Data pretendida:</Text>
          <Text style={styles.value}>25/06/25</Text>

          <Text style={styles.sectionTitle}>Itens (2)</Text>
          <Text style={styles.value}>
            1. Geladeira {"\n"} 
            {"\n"}65 cm (C) x 60 cm (L) x 160 cm (A) {"\n"}
            {"\n"}Na caixa: Sim {"\n"}
            {"\n"}Frágil: Sim{"\n"}
          </Text>
           <Text style={styles.value}>
            2. Cama de Solteiro {"\n"} 
            {"\n"}200 cm (C) x 100 cm (L) x 50 cm (A) {"\n"}
            {"\n"}Na caixa: Não {"\n"}
            {"\n"}Frágil: Não{"\n"}
          </Text>
          <Text style={styles.sectionTitle}>Observações</Text>
          <Text style={styles.value}>
            Moro na última casa da rua.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100,
  },
  card: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'black',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 10,
    color: '#0D2C54',
  },
  value: {
    fontSize: 16,
    color: '#222',
    marginBottom: 5,
  },
});

export default RequestDetailsScreen;



