import React, { useLayoutEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { getGreeting } from '../utils/greetings';
import Ionicons from 'react-native-vector-icons/Ionicons';

const HomeScreen = ({ navigation }) => {
  useLayoutEffect(() => {
    navigation.setOptions({ title: `${getGreeting()}!` });
  }, [navigation]);

  function handleButtonPress() {
    navigation.navigate('Request');
  }

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.atendimento}>
          <Text style={styles.label}>
            Número do pedido: <Text style={styles.value}>202412345679</Text>
          </Text>

          <View style={styles.rowBetween}>
            <Text style={styles.username}>João Silva</Text>
            <Text style={styles.date}>25/06/2025</Text>
          </View>

          <View style={styles.rowBetween}>
            <Text style={styles.phone}>(11) 91234-5677</Text>
            <TouchableOpacity onPress={() => navigation.navigate('RequestDetails')}>
              <Text style={styles.detailsLink}>Ver detalhes</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.trashContainer}>
            <TouchableOpacity onPress={() => console.log('Excluir pedido')}>
              <Ionicons name="trash-outline" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Conteúdo adicional pode ir aqui */}
      </ScrollView>

      {/* Botão fixo no rodapé */}
      <View style={styles.buttonWrapper}>
        <TouchableOpacity
          style={styles.button}
          onPress={handleButtonPress}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonText}>Solicitar Serviço</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100,
  },
  atendimento: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  buttonWrapper: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
    width: '90%',
  },
  button: {
    backgroundColor: '#ffc222',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#222',
    fontSize: 18,
    fontWeight: 'bold',
  },
  label: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  value: {
    fontWeight: 'normal',
  },
  username: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    paddingRight: 140,
  },
  date: {
    fontSize: 18,
    color: '#666',
  },
  phone: {
    fontSize: 16,
    color: '#333',
    paddingRight: 125,
  },
  trashContainer: {
    width: '100%',
    alignItems: 'flex-end',
    marginTop: 10,
  },
  detailsLink: {
    fontSize: 16,
    color: '#0D2C54',
    textDecorationLine: 'underline',
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
});

export default HomeScreen;
