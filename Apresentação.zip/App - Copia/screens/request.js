import React, { useLayoutEffect, useState } from 'react';
import { ScrollView, StyleSheet, TextInput } from 'react-native';
import { useForm } from 'react-hook-form';
import { Header } from '../components/header';
import { UserInfoForm } from '../components/UserInfoForm';
import { ItemList } from '../components/ItemList';
import { Button } from '../components/button';


const RequestScreen = ({ navigation }) => {
  const [items, setItems] = useState([
    {
      id: 1,
      isBoxed: false,
      isFragile: false,
      comprimento: '',
      largura: '',
      altura: '',
      quantidade: '',
      unit: 'cm',
    },
  ]);


  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      nome: '',
      email: '',
      contato: '',
      enderecoRetirada: '',
      enderecoEntrega: '',
      data: '',
    }
  });

  const addItem = () => {
    setItems(prev => [
      ...prev,
      {
        id: prev.length + 1,
        isBoxed: false,
        isFragile: false,
        comprimento: '',
        largura: '',
        altura: '',
        quantidade: '',
        unit: 'm',
      },
    ]);
  };


  const removeItem = (index) => {
    const updated = [...items];
    updated.splice(index, 1);
    setItems(updated);
  };


  const updateItem = (index, key, value) => {
    const updated = [...items];
    updated[index][key] = value;
    setItems(updated);
  };


  const toggleUnit = (index) => {
    const updated = [...items];
    updated[index].unit = updated[index].unit === 'm' ? 'cm' : 'm';
    setItems(updated);
  };


  const toggleBoxed = (index) => {
    const updated = [...items];
    updated[index].isBoxed = !updated[index].isBoxed;
    setItems(updated);
  };


  const toggleFragile = (index) => {
    const updated = [...items];
    updated[index].isFragile = !updated[index].isFragile;
    setItems(updated);
  };


  const onSubmit = (data) => {
    alert('Dados enviados!\n\n' + JSON.stringify({ ...data, itens: items }, null, 2));
  };


  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Header title="Informações da Mudança" />
      <UserInfoForm control={control} errors={errors} />
      <Header title="Dados dos Itens" />
      <ItemList
        items={items}
        updateItem={updateItem}
        toggleUnit={toggleUnit}
        toggleBoxed={toggleBoxed}
        toggleFragile={toggleFragile}
        removeItem={removeItem}
        addItem={addItem}
      />
       <Header title="Observações" />
       <TextInput
         style={styles.observations}
         placeholder="Digite tudo que for pertinente"
         multiline={true}
         numberOfLines={4}
         textAlignVertical="top"
       />
      <Button title="Enviar" onPress={handleSubmit(onSubmit)} />
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#1e3f70',
  },
  observations: {
   marginBottom: 20,
   backgroundColor: '#f4f4f4',
   padding: 10,
   borderRadius: 8,
   minHeight: 100, 
   textAlignVertical: 'top', 
  },
});

export default RequestScreen;