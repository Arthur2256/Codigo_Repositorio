import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import { Controller } from 'react-hook-form';

export const UserInfoForm = ({ control, errors }) => (
  <View style={styles.container}>
  
    <Text style={styles.label}>Nome e Sobrenome</Text>
    <Controller
      control={control}
      name="nome"
      rules={{ required: 'Nome obrigatório' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="Digite aqui"
          maxLength={40} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.nome && <Text style={styles.error}>{errors.nome.message}</Text>}

    <Text style={styles.label}>Email</Text>
    <Controller
      control={control}
      name="email"
      rules={{ required: 'Email obrigatório' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="Digite aqui"
          maxLength={40} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

    <Text style={styles.label}>Telefone ou WhatsApp</Text>
    <Controller
      control={control}
      name="telefone"
      rules={{ required: 'Telefone obrigatório' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="Digite aqui"
          maxLength={14} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.telefone && <Text style={styles.error}>{errors.telefone.message}</Text>}

    <Text style={styles.label}>Endereço de retirada</Text>
    <Controller
      control={control}
      name="enderecoRetirada"
      rules={{ required: 'Endereço de retirada obrigatório' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="Digite aqui"
          maxLength={40} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.enderecoRetirada && <Text style={styles.error}>{errors.enderecoRetirada.message}</Text>}

    <Text style={styles.label}>Endereço de entrega</Text>
    <Controller
      control={control}
      name="enderecoEntrega"
      rules={{ required: 'Endereço de entrega obrigatório' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="Digite aqui"
          maxLength={40} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.enderecoEntrega && <Text style={styles.error}>{errors.enderecoEntrega.message}</Text>}

    <Text style={styles.label}>Data pretendida (Apenas para referência)</Text>
    <Controller
      control={control}
      name="data"
      rules={{ required: 'Data pretendida obrigatória' }}
      render={({ field: { onChange, value } }) => (
        <TextInput
          style={styles.input}
          placeholder="00/00/0000"
          maxLength={10} 
          onChangeText={onChange}
          value={value}
        />
      )}
    />
    {errors.data && <Text style={styles.error}>{errors.data.message}</Text>}
  </View>
);

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    backgroundColor: '#f4f4f4',
    padding: 10,
    borderRadius: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    marginLeft: 5,
    marginTop: 10,
    color: '#333',
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  error: {
    color: 'red',
    fontSize: 12,
    marginBottom: 8,
  },
});


