import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import { Switch, IconButton } from 'react-native-paper';

export const ItemRow = ({ item, index, updateItem, toggleBoxed, toggleFragile, removeItem }) => {
  return (
    <View style={styles.itemContainer}>
      <Text style={styles.itemTitle}>{index + 1}. Item </Text>
      <TextInput style={styles.itemTitle} placeholder= 'Digite o nome do Item'/>

      <View style={styles.measurementsRow}>
        <TextInput
          placeholder={`C (${item.unit})`}
          style={styles.cellInput}
          keyboardType="numeric"
          maxLength={4} 
          value={item.comprimento}
          onChangeText={(text) => updateItem(index, 'comprimento', text)}
        />
        <TextInput
          placeholder={`L (${item.unit})`}
          style={styles.cellInput}
          keyboardType="numeric"
          maxLength={4} 
          value={item.largura}
          onChangeText={(text) => updateItem(index, 'largura', text)}
        />
        <TextInput
          placeholder={`A (${item.unit})`}
          style={styles.cellInput}
          keyboardType="numeric"
          maxLength={4} 
          value={item.altura}
          onChangeText={(text) => updateItem(index, 'altura', text)}
        />
        <TextInput
          placeholder="Qtd"
          style={styles.cellInput}
          keyboardType="numeric"
          maxLength={4} 
          value={item.quantidade}
          onChangeText={(text) => updateItem(index, 'quantidade', text)}
        />
      </View>

      <View style={styles.switchRow}>
        <View style={styles.switchContainer}>
          <Text style={styles.itemLabel}>Na caixa?</Text>
          <Switch
            value={item.isBoxed}
            onValueChange={() => toggleBoxed(index)}
            trackColor={{ false: '#767577', true: '#ffc222' }}  // Cor da trilha (fundo)
            thumbColor={item.isBoxed? '#ffc222' : '#0d2c54'} // Cor do botão deslizante
          />
        </View>
        <View style={styles.switchContainer}>
          <Text style={styles.itemLabel}>É frágil?</Text>
          <Switch
            value={item.isFragile}
            onValueChange={() => toggleFragile(index)}
            trackColor={{ false: '#767577', true: '#ffc222' }}  // Cor da trilha (fundo)
            thumbColor={item.isFragile ? '#ffc222' : '#0d2c54'} // Cor do botão deslizante
          />
        </View>
        <IconButton icon="trash-can" color="black" size={20} onPress={() => removeItem(index)} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 5,
    marginBottom: 15,
  },
  itemTitle: {
    fontWeight: 'bold',
    color: '#0d2c54',
    fontSize: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  measurementsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    flexWrap: 'wrap',
  },
  cellInput: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingHorizontal: 4,
    marginHorizontal: 2,
    marginBottom: 5,
    height: 40,
    textAlign: 'center',
    width: 60,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemLabel: {
    marginRight: 5,
    fontWeight: 'bold',
  },
});
