import React, { useEffect, useState } from 'react';
import { View, Text, Button, ScrollView, Alert, StyleSheet, TouchableOpacity } from 'react-native';
import { supabase } from '../lib/supabase';

export default function UserRequest() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  // Buscar o usuário atual
  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) {
        console.log('Erro ao buscar usuário:', error.message);
      } else {
        setUser(user);
      }
    };

    fetchUser();
  }, []);

  // Buscar os pedidos + itens
  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;

      setLoading(true);
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id);

      if (error) {
        console.log('Erro ao buscar pedidos:', error.message);
      } else {
        setOrders(data);
      }
      setLoading(false);
    };

    fetchOrders();
  }, [user]);

  if (loading) {
    return (
      <View style={styles.container}>
        <Text>Carregando pedidos...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {orders.length === 0 ? (
        <Text>Você ainda não tem pedidos.</Text>
      ) : (
        orders.map((order) => (
          <View key={order.id} style={styles.orderItem}>
            <Text style={styles.orderText}>Produto: {order.product}</Text>
            <Text style={styles.orderText}>Quantidade: {order.quantity}</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
  },
  orderItem: {
    padding: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
  },
  orderText: {
    fontSize: 16,
  },
});