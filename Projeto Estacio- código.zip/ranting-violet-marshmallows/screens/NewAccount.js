import React from 'react';
import { View,Alert, Text, TextInput, StyleSheet } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { Header } from '../components/header';
import { Button } from '../components/button';
import { useState } from 'react';
import { router } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { supabase } from '../lib/supabase'

const NewAccountScreen = () => {
  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      nome: '',
      email: '',
      telefone: '',
      animal: '',
      senha: '',  // ✅ Inclui campo de senha
    }
  });

  const onSubmit = async (data) => {
    const { nome, email, telefone, senha } = data;

    try {
      // 1. Criar usuário na autenticação do Supabase
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email,
        password: senha,
      });

      if (signUpError) {
        alert(`Erro ao criar usuário: ${signUpError.message}`);
        return;
      }

      const userId = authData.user.id;

      // 2. Salvar nome, telefone e email na tabela 'profiles'
      const { error: insertError } = await supabase
        .from('profiles')
        .insert([
          {
            id: userId,
            nome,
            email,
            telefone,
          },
        ]);

      if (insertError) {
        alert(`Erro ao salvar perfil: ${insertError.message}`);
        return;
      }

      alert('Usuário registrado com sucesso!');

    } catch (error) {
      console.error('Erro no cadastro:', error);
      alert('Erro inesperado no registro.');
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Informações de Cadastro" />
      <View style={styles.formBox}>
        {/* Nome */}
        <Text style={styles.label}>Nome</Text>
        <Controller
          control={control}
          name="nome"
          rules={{ required: 'Nome obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.nome && <Text style={styles.error}>{errors.nome.message}</Text>}

        {/* Email */}
        <Text style={styles.label}>Email</Text>
        <Controller
          control={control}
          name="email"
          rules={{ required: 'Email obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

        {/* Telefone */}
        <Text style={styles.label}>Telefone</Text>
        <Controller
          control={control}
          name="telefone"
          rules={{ required: 'Telefone obrigatório' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.telefone && <Text style={styles.error}>{errors.telefone.message}</Text>}

        {/* Senha */}
        <Text style={styles.label}>Senha</Text>
        <Controller
          control={control}
          name="senha"
          rules={{ required: 'Senha obrigatória' }}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Digite aqui"
              secureTextEntry
              onChangeText={onChange}
              value={value}
            />
          )}
        />
        {errors.senha && <Text style={styles.error}>{errors.senha.message}</Text>}

        {/* Botão */}
        <Button title="Registrar" onPress={handleSubmit(onSubmit)} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#fff',
  },
  formBox: {
    marginTop: 20,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  error: {
    color: 'red',
    marginBottom: 10,
  },
});

export default NewAccountScreen;
