import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  StyleSheet,
  Platform,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  TouchableOpacity
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { Button } from '../components/button';
import { supabase } from '../lib/supabase';  // <<< Importação do Supabase

function LoginScreen({ navigation }) {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setIsLoading] = useState(false);

  async function handleButtonPress() {
    if (!user.trim() || !password.trim()) {
      Alert.alert('Campos obrigatórios', 'Por favor, preencha o usuário e a senha para continuar.');
      return;
    }

    setIsLoading(true);

    try {
     const { data, error } = await supabase.auth.signInWithPassword({
  email: user,
  password: password,
});

      if (error) {
        Alert.alert('Erro de Login', error.message);
      } else {
        console.log('Usuário logado:', data.user);
        navigation.navigate('MainTabs', { user: data.user });
      }
    } catch (err) {
      Alert.alert('Erro inesperado', err.message);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={{ flex: 1 }}>
            <View style={styles.innerContainer}>
              {/* Ícones alinhados no centro */}
              <View style={styles.iconRow}>
                <Icon name="truck-loading" size={100} color="#ffc222" style={styles.icon} />
                <Icon name="truck" size={100} color="grey" style={styles.icon} />
              </View>

              {/* Texto centralizado */}
              <Text style={styles.text}>TRANSPORTES E MUDANÇAS</Text>

              {/* Campo usuário */}
              <TextInput
                style={styles.input}
                placeholder="Email"
                value={user}
                onChangeText={setUser}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              {/* Campo senha com botão de mostrar/ocultar */}
              <View style={styles.passwordContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Senha"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                />
                <TouchableOpacity
                  style={styles.eyeIcon}
                  onPress={() => setShowPassword(!showPassword)}
                >
                  <Icon
                    name={showPassword ? 'eye-slash' : 'eye'}
                    size={18}
                    color="#666"
                  />
                </TouchableOpacity>
              </View>

              {/* Botão de login */}
              <View style={styles.buttonContainer}>
                <Button isLoading={loading} title="Entrar" onPress={handleButtonPress} />
              </View>

              {/* Link "Esqueci a senha" */}
              <View style={styles.forgotPasswordContainer}>
                <Text style={styles.forgotPassword} onPress={() => navigation.navigate('ForgotPassword')}>
                  Esqueci a senha
                </Text>
              </View>

              {/* Rodapé */}
              <View style={styles.footerSection}>
                <Text style={styles.footerText}>
                  Não possui uma conta?{' '}
                  <Text
                    style={styles.link}
                    onPress={() => navigation.navigate('NewAccount')}
                  >
                    Criar Conta
                  </Text>
                </Text>
                <Text style={styles.footerText}>Problemas? Nosso suporte: 0000-0000</Text>
              </View>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D2C54',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  innerContainer: {
    flex: 1,
    padding: 20,
    position: 'relative',
    backgroundColor: '#0D2C54',
    justifyContent: 'center',
  },
  iconRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  icon: {
    marginHorizontal: 4,
  },
  text: {
    fontSize: 24,
    color: '#d3d3d3',
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  input: {
    marginBottom: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: '#d3d3d3',
    backgroundColor: 'white',
    padding: 10,
    paddingRight: 40,
    borderRadius: 30,
  },
  passwordContainer: {
    position: 'relative',
    justifyContent: 'center',
  },
  eyeIcon: {
    position: 'absolute',
    right: 20,
    top: '50%',
    transform: [{ translateY: -16 }],
  },
  buttonContainer: {
    marginTop: 10,
    justifyContent: 'center',
  },
  forgotPasswordContainer: {
    alignItems: 'center',
    marginTop: 15,
  },
  forgotPassword: {
    color: '#d3d3d3',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    fontSize: 14,
  },
  footerSection: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    alignItems: 'center',
  },
  footerText: {
    textAlign: 'center',
    color: '#d3d3d3',
    fontSize: 14,
  },
  link: {
    color: '#ffc222',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
});

export default LoginScreen;