import React, { useLayoutEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { Header } from '../components/header';
import { getGreeting } from '../utils/greetings';


const HomeScreen = ({ navigation }) => {


  useLayoutEffect(() => {
    navigation.setOptions({ title: `${getGreeting()}!` });
  }, [navigation]);


  function handleButtonPress() {
    navigation.navigate('Request');
  }


  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.atendimento}>
          <Header title="Horário de Atendimento" />
          <Text>Horário de atendimento</Text>
        </View>
        {/* Conteúdo adicional pode ir aqui */}
      </ScrollView>


      {/* Botão fixo no rodapé */}
      <View style={styles.buttonWrapper}>
        <TouchableOpacity
          style={styles.button}
          onPress={handleButtonPress}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonText}>Solicitar Serviço</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100, // espaço extra para não cobrir o conteúdo com o botão
  },
  atendimento: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  buttonWrapper: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
    width: '90%',
  },
  button: {
    backgroundColor: '#ffc222',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#222',
    fontSize: 18,
    fontWeight: 'bold',
  },
});


export default HomeScreen;