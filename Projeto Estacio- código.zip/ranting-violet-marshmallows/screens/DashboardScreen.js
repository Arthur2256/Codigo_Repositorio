import React, { useLayoutEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { Header } from '../components/header';
import WorkCalendar from '../components/WorkCalendar'; // ← Importa o novo componente
import { getGreeting } from '../utils/greetings';

const DashboardScreen = ({ navigation }) => {
  useLayoutEffect(() => {
    navigation.setOptions({ title: `${getGreeting()}!` });
  }, [navigation]);

  // Marcação de datas (vazio por enquanto, será preenchido depois via banco de dados)
  const marked = {};

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.calendar}>
          <Text style={styles.calendartext}> Calendário de Atendimentos </Text>
          <WorkCalendar markedDates={marked} />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },
  container: {
    padding: 20,
    paddingBottom: 100,
  },
  calendar: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
  },
   calendartext: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#0D2C54',
  },
});

export default DashboardScreen;

