import { View, Text, StyleSheet} from 'react-native';

function AboutScreen({navigation}) {

return (
<View style={styles.container}>
  <Text style={styles.text}>
    A [Nome da Empresa] é uma empresa que se destaca pelo compromisso com a excelência e pelo cuidado que dedica aos seus clientes. Trabalhamos com paixão para oferecer soluções inovadoras e de qualidade, sempre buscando entender as necessidades de cada um e oferecer o melhor serviço possível.
  </Text>


  <Text style={styles.text}>
  Com uma equipe dedicada e profissional, estamos sempre dispostos a ouvir, aprender e melhorar. Acreditamos que o verdadeiro sucesso vem de fazer a diferença na vida de nossos clientes, e é por isso que buscamos constantemente transformar os desafios em oportunidades de crescimento.
  </Text>


  <Text style={styles.text}>
   Nosso compromisso vai além de entregar um serviço ou produto. Nós nos empenhamos em criar experiências positivas e duradouras, fazendo com que nossos clientes se sintam valorizados e satisfeitos. Estamos sempre em movimento, buscando evolução, adaptando-nos às mudanças do mercado e implementando melhorias contínuas.
  </Text>


  <Text style={styles.text}>
    A [Nome da Empresa] não é apenas uma empresa, mas um parceiro que acompanha o seu caminho, transformando desafios em conquistas e criando soluções que realmente fazem a diferença.
  </Text>
</View>


);
}


const styles = StyleSheet.create({
  container:{
  flex: 1,
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor:'white',
  },
  text: {
    textAlign: 'justify',  // Aqui é onde justificamos o texto
    lineHeight: 20,        // Ajuste opcional para melhorar a legibilidade
    padding: 20,
    fontSize: 14,
    color: 'black',
    fontWeight: 'bold',
    marginBottom: 15,
    },
})


export default AboutScreen;
