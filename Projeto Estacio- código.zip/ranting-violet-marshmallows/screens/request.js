import React, { useLayoutEffect, useState } from 'react';
import { ScrollView, StyleSheet, TextInput, Alert } from 'react-native';
import { useForm } from 'react-hook-form';
import { Header } from '../components/header';
import { UserInfoForm } from '../components/UserInfoForm';
import { ItemList } from '../components/ItemList';
import { Button } from '../components/button';
import { supabase } from '../lib/supabase';

const RequestScreen = ({ navigation }) => {
  const [items, setItems] = useState([
    {
      id: 1,
      isBoxed: false,
      isFragile: false,
      comprimento: '',
      largura: '',
      altura: '',
      quantidade: '',
      unit: 'cm',
    },
  ]);

  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      nome: '',
      email: '',
      telefone: '',
      endereco: '',
      cidade: '',
      estado: '',
      cep: '',
    },
  });

  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: () => <Header title="Novo Requerimento" />,
    });
  }, [navigation]);

  const onSubmit = async (data) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      const { error } = await supabase
        .from('orders')
        .insert([{
          user_id: user.id,
          user_info: data,
          items: items,
        }]);

      if (error) throw error;

      Alert.alert('Sucesso', 'Requerimento enviado com sucesso!');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Erro', error.message);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <UserInfoForm control={control} errors={errors} />
      <ItemList items={items} setItems={setItems} />
      <Button title="Enviar Requerimento" onPress={handleSubmit(onSubmit)} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
});

export default RequestScreen;