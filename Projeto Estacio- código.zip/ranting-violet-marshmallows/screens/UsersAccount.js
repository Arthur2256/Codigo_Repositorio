import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Button } from '../components/button';

function UsersAccountScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Tela de Perfil * Vai ter outras configurações</Text>
      <Button title= 'Sobre a empresa' onPress={() => navigation.navigate('About')} /> //posteriormente, vai ter outras coisas
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 18,
    fontWeight: 'bold',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default UsersAccountScreen;

