import React from 'react';
import { View, StyleSheet } from 'react-native';
import { ItemRow } from './ItemRow';
import { Button } from './button';

export const ItemList = ({ items, updateItem, toggleBoxed, toggleFragile, removeItem, addItem }) => {
  return (
    <View style={styles.container}>
      {items.map((item, index) => (
        <ItemRow
          key={item.id}
          item={item}
          index={index}
          updateItem={updateItem}
          toggleBoxed={toggleBoxed}
          toggleFragile={toggleFragile}
          removeItem={removeItem}
        />
      ))}
      <View style={styles.buttonRow}>
        <Button title="Adicionar item +" onPress={addItem} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    backgroundColor: '#f4f4f4',
    padding: 10,
    borderRadius: 8,
  },
  buttonRow: {
    alignItems: 'center',
    marginTop: 10,
  },
});


