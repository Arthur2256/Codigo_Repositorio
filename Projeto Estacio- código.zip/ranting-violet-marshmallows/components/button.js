import React from 'react';
import {StyleSheet, Text, TouchableOpacity, ActivityIndicator} from 'react-native';

export function Button({title, onPress, isLoading = false}) {
  return (
    <TouchableOpacity
    disabled={isLoading}
    onPress={onPress} style={styles.container}>
      {isLoading ? (
        <ActivityIndicator color='black' />
      ) : (
        <Text style={styles.title}>{title}</Text>
       
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffc222',
    paddingVertical: 10,     // mais espaço interno na vertical
    paddingHorizontal: 24,   // se quiser mais largura automática
    width: '50%',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    borderRadius: 30,
    marginBottom: 10,  
  },
  title: {
    color: '#222',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
