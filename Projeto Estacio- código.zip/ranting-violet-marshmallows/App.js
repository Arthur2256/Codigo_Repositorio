import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import LoginScreen from './screens/login';
import HomeScreen from './screens/home';
import NewAccountScreen from './screens/NewAccount'
import AdminScreen from './screens/admin';
import AboutScreen from './screens/about';
import RequestScreen from './screens/request';
import ForgotPasswordScreen from './screens/ForgotPassword';
import UsersAccountScreen from './screens/UsersAccount';
import UsersRequestScreen from './screens/UsersRequest';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();


function TabNavigator({ route }) {
  const { username } = route.params || {};


  return (
    <Tab.Navigator 
    initialRouteName="Home" //Controla a primeira tela tab
    screenOptions={{
      tabBarActiveTintColor: '#ffc222',
      tabBarInactiveTintColor: '#b0b0b0',
      tabBarStyle: { backgroundColor: '#0D2C54' },
      headerStyle: { backgroundColor: '#0D2C54'},
      headerTintColor: '#fff', // Cor dos ícones e texto na barra superior
      headerTitleStyle: {
      fontWeight: 'bold'},
   
    }}>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        initialParams={{ username }}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home" size={size} color={color} />
          ),
        }}
      />
        <Tab.Screen
        name="Pedidos Arquivados"
        component={UsersRequestScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="clipboard" size={size} color={color} />
          ),
        }}
      />
       <Tab.Screen
        name="Minha Conta"
        component={UsersAccountScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-circle" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}


export default function App() {
  return (
    <>
    <StatusBar barStyle="light-content" backgroundColor="#222" />
      <NavigationContainer>
        <Stack.Navigator 
          initialRouteName="Login" //Controla a primeira tela stack
          screenOptions={{
          headerStyle: { backgroundColor: '#0D2C54' }, // não aparece por causa do headershown
          headerTintColor: '#fff',      
          headerTitleStyle: { fontWeight: 'bold' },
          headerBackTitleVisible: false,
          headerBackImage: ({ tintColor }) => (
            <Ionicons
            name="arrow-back"
            size={24}
            color={tintColor}
            style={{ marginLeft: 10 }}/>
          ),
        }}>
         <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
         <Stack.Screen name="About" component={AboutScreen}options={{title:'Sobre a empresa'}}/>
         <Stack.Screen name="Request" component={RequestScreen}options={{title:'Solicitação de Serviço'}}/>
         <Stack.Screen name="MainTabs" component={TabNavigator} options ={{headerShown: false}} />
         <Stack.Screen name="NewAccount" component={NewAccountScreen} options={{title:'Cadastro'}}/>
         <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} options={{title:'Redefinição de Senha'}}/>
         <Stack.Screen name="Admin" component={AdminScreen} options ={{headerShown: false}} />
        </Stack.Navigator>
      </NavigationContainer>
   </>
  );
}




//options={{ headerTransparent: true }}